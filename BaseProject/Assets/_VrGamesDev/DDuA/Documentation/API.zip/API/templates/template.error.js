$(function() {
    registerTemplate('error',`
        <h1 id="page-heading">Page not found</h1>
    `);
});